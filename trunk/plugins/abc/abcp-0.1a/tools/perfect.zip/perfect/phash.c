/* table for the mapping for the perfect hash */
#ifndef STANDARD
#include "standard.h"
#endif /* STANDARD */
#ifndef PHASH
#include "phash.h"
#endif /* PHASH */
#ifndef LOOKUPA
#include "lookupa.h"
#endif /* LOOKUPA */

/* small adjustments to _a_ to make values distinct */
ub2 tab[] = {
65,319,285,258,264,62,23,131,154,0,328,36,28,28,258,243,
230,258,328,6,162,36,214,39,23,264,136,154,258,154,27,264,
154,319,230,0,327,328,0,183,211,166,326,62,328,328,0,112,
154,338,154,243,201,162,62,337,6,28,258,0,28,0,201,67,
364,6,26,157,6,238,0,60,211,223,230,258,65,3,264,0,
154,374,258,243,379,238,117,62,154,154,26,211,62,256,264,174,
108,364,365,308,337,154,154,154,226,258,139,23,154,155,308,65,
341,136,0,162,7,252,3,174,370,201,264,0,0,328,318,261,
};

/* The hash function */
static ub4 phash(key, len)
char *key;
int   len;
{
  ub4 rsl, val = lookup(key, len, 0x7c3c1176);
  rsl = ((val>>25)^tab[val&0x7f]);
  return rsl;
}

